#include <SFML/Graphics.hpp>
#include <vector>
#include <string>

#include "Chargement.hpp"

class Background
{

};