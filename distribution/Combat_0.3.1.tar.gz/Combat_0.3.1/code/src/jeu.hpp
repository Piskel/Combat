#include <iostream>
#include <string>
#include <SFML/Graphics.hpp>

#include "Joueur.hpp"

int jeu(sf::RenderWindow *fenetre, int type, Joueur *j1, Joueur *j2);
int pause(sf::RenderWindow *fenetre, sf::View vue);