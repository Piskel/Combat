#include <SFML/Graphics.hpp>

int credits(sf::RenderWindow *fenetre);